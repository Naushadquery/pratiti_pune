package com.nau.day9.db;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Arrays;

public class DBCon {

	public static void main(String[] args) throws Exception {
		String url = "jdbc:mysql://192.168.0.55:3306/akanksh_pratiti";
		String user = "Akanksh";
		String password = "Akanksh";
		Connection con = DriverManager.getConnection(url, user, password);
		System.out.println("connected");
		
//		CallableStatement cal = con.prepareCall("{Call procedure(?,?)}");
//		cal.execute();
//		Statement st = con.createStatement();
		String name = "Naushad3";
//		String sql1 = "insert into student (fname) values('Naushad1'),('pappu')";
//		String sql2 = "insert into student (fname) values('Akhtar1')";
//		st.addBatch(sql1);
//		st.addBatch(sql2);
//		int i[] =st.executeBatch();
//		String sql1 = "insert into student (fname) values(?)";
//		PreparedStatement ps = con.prepareStatement(sql1);
//		ps.setString(1, name);
//		int i =ps.executeUpdate();
//		
//		String sql2 = "update student set fname=? where fname=?";
//		PreparedStatement ps2 = con.prepareStatement(sql2);
//		ps2.setString(1, "AAAA");
//		ps2.setString(2,"Naushad");
//		int i2 =ps2.executeUpdate();
//		System.out.println(i2);

		String sql3 = "select * from student where id=?";
		PreparedStatement ps3 = con.prepareStatement(sql3);
		ps3.setInt(1, 6);
		ResultSet rs =  ps3.executeQuery();
		if(rs.next()) {
			System.out.printf(rs.getInt(1) + ":" +rs.getString(2));
		}
		
	}

}

package com.nau.day9;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;

public class PropertyDemo {

	public static void main(String[] args) {

		Properties properties = new Properties();
		properties.put("name", "Naushad");
		properties.put("city", "Mumbai");
		try (FileWriter fileWriter = new FileWriter("info.properties")) {
			properties.store(fileWriter, "Personl Info");
			System.out.println("Properties file saved");
//			System.out.println(properties.getProperty("name"));
//			System.out.println(properties.getProperty("city"));
		} catch (IOException e) {
			e.printStackTrace();
		}
//		Properties p = new Properties();
//		try (FileReader fr = new FileReader("info.properties")) {
//			p.load(fr);
//			System.out.println(p.getProperty("name"));
//			System.out.println(p.getProperty("city"));
//			//System.out.println(p.getProperty("battery"));
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}

	}

}

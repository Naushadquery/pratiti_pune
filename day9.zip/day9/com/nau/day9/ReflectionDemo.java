package com.nau.day9;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

class A extends B{
	public A() {
		System.out.println("A object created");
	}
	private void aaM() {
		System.out.println("private method aam");
	}
	
}
class B{
	public B() {
		System.out.println("B object created");
	}
	private void bbM() {
		System.out.println("private method bbm");
	}
}
public class ReflectionDemo {
	
	public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException {
		
		String a = args[0];
		System.out.println(a);
		
		Class<?> c = Class.forName(a);
		Constructor<?> con = c.getDeclaredConstructor();
		Object o = con.newInstance();
		String cname = o.getClass().getName();
		System.out.println(cname);
		Method m = c.getDeclaredMethod("aaM");
		m.setAccessible(true);
		m.invoke(o);
		
	} 

}

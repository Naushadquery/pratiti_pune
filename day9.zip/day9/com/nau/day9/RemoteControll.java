package com.nau.day9;

interface Battery {}
class PanasonicBattery implements Battery{}
class NipponBattery implements Battery{}
class DuracellBattery implements Battery{}

public class RemoteControll {

	private Battery battery;

	public RemoteControll(Battery battery) {
		this.battery = battery;
		System.out.println(battery.getClass().getName());
	}

	public void on() {
		if (battery != null) {
			System.out.println("On");
		} else {
			System.out.println("Battery Required");
		}
	}

	public void off() {
		if (battery != null) {
			System.out.println("OFF");
		} else {
			System.out.println("Battery Required");
		}
	}
}

package com.nau.day9;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Properties;

public class TV {
	public static void main(String[] args) throws Exception {
		Properties prop = new Properties();
		prop.load(new FileReader("info.properties"));
		String battery = prop.getProperty("batteryNippon");
		Object obj = Class.forName(battery).getDeclaredConstructor().newInstance();
		Battery batteryObj = (Battery) obj;
		RemoteControll remoteControll = new RemoteControll(batteryObj);
		remoteControll.on();
	}
}

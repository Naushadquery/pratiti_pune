package com.nau.view;

import java.util.Scanner;

import com.nau.model.Student;
import com.nau.service.StudentService;

public class StudentView {

	private StudentService service = new StudentService();
	private Scanner scanner = new Scanner(System.in);

	public StudentView() {
		System.out.println(Color.RED + "===================================" + Color.RESET);
		System.out.println(Color.GREEN + "**** Student Management System ****" + Color.RESET);
		System.out.println(Color.RED + "===================================" + Color.RESET);
		mainOption();
	}

	private void mainOption() {

		System.out.println(Color.BLUE);
		System.out.println("-- Main Menu --");
		System.out.println("1. Add Student");
		System.out.println("2. View Students");
		System.out.println("3. Delete Students");
		System.out.println("4. Delete Students");
		System.out.println("5. Get Student By Id");
		System.out.println("6. Exit");
		System.out.println(Color.RESET);
		System.out.println(Color.GREEN + Color.WHITE_BG + "Enter Option : " + Color.RESET);
		int option = scanner.nextInt();
		//System.out.print(option);
		doOption(option);

	}

	private void doOption(int option) {
		switch (option) {
		case 1: {
			addStudent();
			mainOption();
			break;
		}
		case 2: {
			viewStudent();
			mainOption();
			break;
		}
		case 3: {
			getStudentById();
			mainOption();
			break;
		}
		case 6: {
			System.out.println("***********************************");
			System.out.println(Color.RED + "Thank You, Visit Again" + Color.RESET);
			System.out.println("***********************************");
			System.exit(0);
			return;
		}
		default:
			throw new IllegalArgumentException("Unexpected value: " + option);
		}

	}

	private void addStudent() {
		Student students[] = new Student[3];
		int id = 1;//user input
		boolean result = service.verifyId(id);
		//
		Student student = new Student(id,"nausha","mumbai");
		students[0] = student;
		
		service.addStudent(students);
		
	}

	private void getStudentById() {
		return;
	}

	private void viewStudent() {
		return;
	}

}

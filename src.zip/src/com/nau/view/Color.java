package com.nau.view;

public interface Color {
	String RESET = "\u001B[0m";
    String RED = "\u001B[31m";
    String GREEN = "\u001B[32m";
    String YELLOW = "\u001B[33m";
    String BLUE = "\u001B[36m";
    String WHITE_BG = "\u001B[47m";
}

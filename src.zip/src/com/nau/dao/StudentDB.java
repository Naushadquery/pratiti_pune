package com.nau.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

import com.nau.model.Student;

public final class StudentDB {
	
	private Student students[];

	public boolean addStudent(Student... students) {
		
		return false;
	}
	
	public boolean getStudentById(int id) {
		
		return false;
	}
	
	public StudentDB() {
		File file = new File("student_record.db");
		if(file.exists()) {
			
			try(ObjectInputStream obj = new ObjectInputStream(new FileInputStream(file))) {
				StudentTable studentTable = (StudentTable)obj.readObject();
				students = studentTable.getStudents();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
		}else {
			try {
				file.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}

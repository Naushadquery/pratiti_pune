package com.nau.dao;

import java.io.Serializable;

import com.nau.model.Student;

public class StudentTable implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private Student students[] = new Student[10];

	public Student[] getStudents() {
		return students;
	}

	public void setStudents(Student[] students) {
		this.students = students;
	}
	
	
}

package com.nau.service;

import com.nau.dao.StudentDB;
import com.nau.model.Student;

public class StudentService {
	
	private StudentDB db = new StudentDB();
	
	public boolean verifyId(int id) {
		return db.getStudentById(id);
	}
	
	public void addStudent(Student... students) {
		db.addStudent(students);
	}
}

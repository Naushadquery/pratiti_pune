console.log("f1 page loaded");
const calc1 = (i, j) => {
  return i * j;
};
const calc2 = (i, j) => {
  return i - j;
};

module.exports = { calc1, calc2 };

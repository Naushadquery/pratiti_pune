const http = require("http");

server = http.createServer(function (req, res) {
  res.write("WElcome to Naushad Bhai Server");
  res.end();
});
console.log("server started");

server.listen(80);

const f = require("./f1");

console.log("hello page loaded");
let res = f.calc2(2, 2);
console.log(res);

const f2 = require("./f2");

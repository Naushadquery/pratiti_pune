package com.nau.day6.exp;

public class Calculator {
	public byte calc(byte i, byte j)throws ByteLimitException {
		if(i>63) {
			throw new ByteLimitException(i);
		}
		return (byte)(i+j);
	}
}

package com.nau.day6.exp;

public class ByteLimitException extends Exception {
	
	public ByteLimitException(byte i) {
		super(i + " value is greater than 63");
	}
	@Override
	public String toString() {
		return getClass().getName() + ": " + getMessage();
	}
}

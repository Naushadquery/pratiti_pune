package com.nau.day6.exp;

public class CalcApp {
	public static void main(String[] args) {
		Calculator calculator = new Calculator();
	
			byte a = 122;
			byte b = 122;
			int res;

			try {
				res = calculator.calc(a, b);
				System.out.println(res);
			} catch (ByteLimitException e) {
				byte aa = 44;
				try {
					res = calculator.calc(aa, b);
					System.out.println(res);
				} catch (ByteLimitException e1) {
					e1.printStackTrace();
				}
			
			}
	}
}

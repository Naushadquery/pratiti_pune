package com.nau.day6;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class ExpDemo {
	
	public static void main(String[] args) {
		System.out.println("start");
		
//		try {
//			FileInputStream fis = new FileInputStream("abc.txt");
//		} catch (FileNotFoundException e) {
//			System.out.println(e.getMessage());
//			System.out.println(e.toString());
//		}
		
		int len = args.length;
		try {
			String n1 = args[0];
			String n2 = args[1];
			// if(n1.matches("[0-9]*") && n2.matches("[0-9]*")) {
				 Integer sum = Integer.parseInt(n1)+Integer.parseInt(n2);
					System.out.println(sum);
//			 }else {
//				 System.out.println("Enter numeric only");
//			 }
			
		}finally {
			System.out.println("Finally");
		}
		System.out.println("After Catch block");
		 
		System.out.println("end");
	}
}

package com.nau.day6;

public interface ThingsInInterface {

	public static final int X = 40;
	
//	void abc1();
//	void abc2();
//	void abc3();
	
	default void abc4() {
		System.out.println("abc44");
		ppp();
	}
	private void ppp() {
		
	}
	default void abc5() {
		System.out.println("abc55");
	}
	static void abc6() {
		System.out.println("abc66 static");
	}
	

}

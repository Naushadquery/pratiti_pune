package com.nau.day6;

@FunctionalInterface
interface KK{
	int kp(int i,int j);
	default void kp1() {};
}

public class TIIImpl {
	
	public TIIImpl() {
		
	}
	
	public void fi(KK k, int i,int j) {
		int res =  k.kp(i,j);
		System.out.println("RES : " + res );
	}

}

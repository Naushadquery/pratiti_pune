package com.nau.day6;

public interface IB {
	public default void sum(int i, int j) {
		System.out.println(i+j+1);
	}
}

package com.nau.day6;

public class AA implements TP{
	
	public static void main(String[] args) {
		
		AA aa = new AA();
		aa.tp();
		
	}

}

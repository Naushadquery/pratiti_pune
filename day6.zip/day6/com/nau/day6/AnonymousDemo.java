package com.nau.day6;

public class AnonymousDemo {

	public static void main(String[] args) {
		new Anony();

		TIIImpl tiiImpl = new TIIImpl();
		KK k = new KK() {
			@Override
			public int kp(int i, int j) {
				System.out.println("KK AYAAAAAA " + (i + j));
				return i + j;
			}
		};
		KK k1 = (x, y) -> x + y;

		tiiImpl.fi((x, y) -> x + y, 8, 9);
	}

}

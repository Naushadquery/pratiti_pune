package com.nau.day6;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JFrame;

public class Anony extends JFrame {
//	private class WindowAdapterInnerImpl extends WindowAdapter{
//		@Override
//		public void windowClosing(WindowEvent e) {
//			System.out.println("windowClosing Hogaya");
//			System.exit(0);
//		}
//	}
	private JButton b1, b2;

	public Anony() {
		createComponents();
		addComponentsToFrame();
		addEventListeners();
		display();
	}

	private void addEventListeners() {
//		 class WindowAdapterLocalImpl extends WindowAdapter{
//			@Override
//			public void windowClosing(WindowEvent e) {
//				System.out.println("windowClosing Hogaya , method ke andhar");
//				System.exit(0);
//			}
//		}
		// WindowAdapterLocalImpl impl = new WindowAdapterLocalImpl();
		WindowAdapter adapter = new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				System.out.println("windowClosing Hogaya , method ke andhar , anoy");
				System.exit(0);
			}
		};
		addWindowListener(adapter);
		ActionListener actionListener = new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println("Button clicked " + ((JButton) e.getSource()).getText());
			}
		};
		ActionListener al = e -> System.out.println("Button clicked " + ((JButton) e.getSource()).getText());
		b1.addActionListener(e -> System.out.println("Button clicked " + ((JButton) e.getSource()).getText()));
		b2.addActionListener(actionListener);
	}

	private void createComponents() {
		b1 = new JButton("Button1");
		b2 = new JButton("Button2");
	}

	private void addComponentsToFrame() {
		add(b1, BorderLayout.NORTH);
		add(b2, BorderLayout.SOUTH);
	}

	public void display() {
		setSize(600, 400);
		setVisible(true);
	}

}

package com.nau.day6;

public interface TP {

	default void tp() {
		String n = getClass().getName();
		System.out.println(n);
	}
	
}

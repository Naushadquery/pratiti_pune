package com.nau.day6.io;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class IODemo {

	public static void main(String[] args) throws IOException {

//		OutputStream out = System.out;
//		out.write(65);
//		out.flush();

		ServerSocket ss = new ServerSocket(1234);
		for (;;) {
			System.out.println("Waiting....");
			Socket s = ss.accept();
			System.out.println(s);
			InputStream is = s.getInputStream();
//			DataInputStream dis = new DataInputStream(is);
			InputStreamReader isr = new InputStreamReader(is);
			BufferedReader dis = new BufferedReader(isr);
			System.out.println("A");
			String msg = dis.readLine();
			System.out.println("B");
			System.out.println(msg);
			dis.close();
			OutputStream os = s.getOutputStream();
			OutputStreamWriter osw = new OutputStreamWriter(os);
			BufferedWriter br = new BufferedWriter(osw);
			br.write("Welocme to naushad server");
			br.flush();
			//dis.close();
			//is.close();
			//s.close();
		}

//		Socket socket = new Socket("192.168.0.76",1234) ;
//		OutputStream sos = socket.getOutputStream();
//		byte msg[] = "Hello From Naushad".getBytes();
//		sos.write(msg);
//		sos.flush();
		
		

	}

}

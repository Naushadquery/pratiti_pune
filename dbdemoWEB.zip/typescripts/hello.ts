console.log("TS File");
let fname: string;
fname = "asdf";
console.log(fname);
const names: readonly string[] = ["Dylan"];
class Person {
  private readonly name: string;

  public constructor(name: string) {
    // name cannot be changed after this initial definition, which has to be either at it's declaration or in the constructor.
    this.name = name;
  }

  public getName(): string {
    return this.name;
  }
}

const person = new Person("Jane");
console.log(person.getName());

// const express = require("express");
// const app = express();

// app.set("view engine", "ejs");

class Employee {
  constructor(uname, city) {}
}

const info = [
  {
    uname: "Naushad Akhtar",
    city: "pune",
  },
  {
    uname: "Akanksh ",
    city: "latur",
  },
];

const emp = info;

console.log(emp[0]);

// app.get("/", (req, res) => {
//   res.render("home", { data: info });
// });

// app.listen(9999, () => {
//   console.log("Server Started with EJS");
// });

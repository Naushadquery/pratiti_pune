const http = require("http");
const url = require("url");
const fs = require("fs");
const bodyparser = require("body-parser");
server = http.createServer(function (req, res) {
  // http://192.168.0.132:8888
  res.writeHead(200, { "Content-Type": "text/html" });

  requrl = req.body.parse;
  // console.log(url.parse(requrl, true));
  // q = url.parse(requrl, true).query;
  // console.log(q);
  //uname = q.uname;

  console.table(requrl);

  // path = q.pathname;
  // if (path == "/") {
  //   fs.readFile("index.html", (err, data) => {
  //     res.write(data.toString());
  //     res.end();
  //   });
  // }
  // if (path == "/validate") {
  //   qq = q.query;
  //   let uid = qq.uid;
  //   res.write("Welcome " + uid);
  //   res.end();
  // }
});
console.log("server started");

server.listen(8888); // IP: 132

const express = require("express");
const path = require("path");
const cors = require("cors");
const fs = require("fs");
const app = express();
const port = 8888;
//app.use(cors());

app.use("/static/css", express.static(path.join(__dirname, "public/css")));

app.get("/", (req, res) => {
  res.sendFile("./views/index.html", { root: __dirname });
});
app.get("/login", cors(), (req, res) => {
  res.sendFile("./views/login.html", { root: __dirname });
});
app.listen(port, () => {
  console.log(`Example app listening on port ${port}`);
});

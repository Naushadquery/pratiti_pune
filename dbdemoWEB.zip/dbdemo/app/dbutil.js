const mysql = require("mysql2");
const url = "localhost";
const user = "naushad";
const password = "naushad";
const dbname = "naushad_pratiti";

var con = mysql.createConnection({
  host: url,
  user: user,
  password: password,
  database: dbname,
});
con.connect(function (err) {
  if (err) throw err;
  console.log("Connected!");
});
module.exports = con;

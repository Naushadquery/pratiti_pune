const con = require("./dbutil");

const addStudent = (student) => {
  let sql = "insert into student (fname )value ?";
};

const getStudents = () => {
  let sql = "select * from  student";
};

const getStudentById = (id) => {
  let sql = "select * from  student where id=" + id;
};

module.exports = { addStudent, getStudentById, getStudents };

const { getStudentById, getStudents, addStudent } = require("./dao");

const verifyStudent = (id, password) => {
  let student = getStudentByIdService(id);
  if(password==student.password){
    
  }
};
const addStudentService = (...student) => {
  addStudent(student);
};

const getStudentsService = () => {};

const getStudentByIdService = (id) => {
  let student = getStudentById(id);
};

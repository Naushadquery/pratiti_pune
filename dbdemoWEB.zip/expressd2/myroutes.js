const express = require("express");
const router = express.Router();

const employees = [
  { empid: 1, ename: "naushad" },
  { empid: 2, ename: "akash" },
];
function Employee(eid, ename) {
  this.eid = eid;
  this.ename = ename;
}
e1 = new Employee(111, "AAAAA");
e2 = new Employee(222, "BBBB");
emps = [e1, e2];
router.get("/", (req, res) => {
  res.sendFile("index.html", { root: __dirname });
});
router.get("/emp/:id", (req, res) => {
	
  res.json(emps);
});
router.get("/one", (req, res) => {
  uname = req.query.uname;
  res.send("One URL  called GET " + uname);
});
router.get("/two/uname/:uname/pwd/:pwd", (req, res) => {
  uname = req.params.uname;
  pwd = req.params.pwd;
  res.send("Two URL  called GET " + uname + " " + pwd);
});
router.post("/one", (req, res) => {
  res.send("One URL  called POST");
});
router.put("/one", (req, res) => {
  res.send("One URL  called PUT");
});

module.exports = router;

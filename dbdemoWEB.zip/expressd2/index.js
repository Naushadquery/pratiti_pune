const express = require("express");
const cors = require("cors");
const app = express();
const route = require("./myroutes");
app.use(cors());
app.use(route);

app.listen(8888, () => console.log("server started"));

const http = require("http");

server = http.createServer(function (req, res) {
  res.write("WElcome to Naushad Bhai Server 8888");
  //res.end();
});
console.log("server started");

server.listen(8888); // IP: 132

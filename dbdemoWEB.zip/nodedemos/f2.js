console.log("f2 page loaded for file reading");
const fs = require("fs");

console.log("START");

fs.readFile("papa.txt", function (err, data) {
  console.log(data.toString());
});

console.log("END");

package com.nau;

public class Hello {

	public static void main(String[] args) {
		System.out.println("Hello World");
		Tp tp = new Tp();
		Integer ii = 34;
		Integer jj = 44;
		//tp.tt(ii+jj);
		System.out.println(ii+jj);
	}
}

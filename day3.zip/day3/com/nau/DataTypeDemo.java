package com.nau;

public class DataTypeDemo {
	
	public static void main(String[] args) {
		
		// Wrapper Classes
		Byte b1 = 127;
		Byte b2 = 33;
		System.out.println(b1+b2);
		byte a = 1;  // 1 
		byte aa = 11;
		byte cc = (byte)(a+aa);
		System.out.println(cc);
		short b = 2; // 2
		int c = 3; // 4
		Integer c1 = 34;
		
		long d = 922337203787L; // 8
		float e = 45.454F;  // 4
		double f = 3434.34; // 8
		char g = 'A';
		boolean h = true;
		System.out.println(Long.MAX_VALUE);
		System.out.println(a+a);
		
		Tp tp = new Tp();
		byte kk = 125;
		//byte jj = 6;
		
		tp.tt(11);
				
	}
	

}

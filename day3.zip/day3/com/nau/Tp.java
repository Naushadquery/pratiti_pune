package com.nau;

class Tp {

//	public void tt(int b)
//
//	{
//		System.out.println("byte" +  b);
//		
//
//	}
	public void tt(Integer b)

	{
		System.out.println("int" + b);

	}
//	

}
package com.nau.tic;

public class TICApp {
	public static void main(String[] args) {
		ThingsInClass tic = new ThingsInClass();
//		tic.setAge(33);
//		System.out.println(tic.getAge());
//		
//		ThingsInClass tic1 = new ThingsInClass();
//		tic1.setAge(44);
//		System.out.println(tic1.getAge());
//		tic1.ThingsInClass();
//		
//		ThingsInClass.count =40;
//		ThingsInClass.count = 50;
//		System.out.println(ThingsInClass.count);
//		int x = ThingsInClass.count;
//		System.out.println(x);
		int y = ThingsInClass.count;
		System.out.println(y);
		
	}
}

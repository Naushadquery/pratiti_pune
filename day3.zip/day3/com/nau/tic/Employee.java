package com.nau.tic;

public class Employee {

	private int id;
	private String name;

	private static int count;

	public Employee() {
		addEmployee();
	}

	private static void addEmployee() {
		count++;
		
	}

	public static void deleteEmployee() {
		count--;
	}

	public static int getEmployeeCount() {
		return count;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}

package com.nau.tic;

public class EmployeeApp {
	public static void main(String[] args) {

		Employee employee1 = new Employee();
		Employee employee2 = new Employee();
		Employee employee3 = new Employee();
		System.out.println(Employee.getEmployeeCount());

		
		Employee.deleteEmployee();
		System.out.println(Employee.getEmployeeCount());

	}
}

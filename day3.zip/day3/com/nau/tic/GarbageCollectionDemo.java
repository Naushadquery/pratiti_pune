package com.nau.tic;

class Tp{
	int objNo ;
	static int objCount;
	public Tp(int i) {
		this.objNo = i;
		objCount++;
		System.out.println(objNo + "obj created");
	}
	@Override
	protected void finalize() throws Throwable {
		System.out.println(objNo + " is deleted");
	}
}

public class GarbageCollectionDemo {
	
	public static void main(String[] args) {
	
		Tp tp = new Tp(1);
		Tp tp1 = new Tp(2);
		
		tp = tp1;
		
		System.gc();
		
		System.out.println("End");
		
//		for (int i = 0; i < 1000000; i++) {
//			Tp tp  = new Tp(i);
//		}
//		System.out.println("Object count " + Tp.objCount);
	}

}

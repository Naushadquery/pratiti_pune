package com.nau.tic;


public class ThingsInClass {

	private int age;

	static int count;

	static{
		System.out.println("Static block called " + ++count);
	}
	{
		System.out.println("ThingInclass Object created1");
	}
	{
		System.out.println("ThingInclass Object created2");
	}

	public ThingsInClass() {

	}

	public ThingsInClass(int i) {

		System.out.println(i + i);
	}

	public void ThingsInClass() {
		System.out.println("ThingInclass method created");
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		if (age > 60) {
			System.out.println("Get Lost, you are too old");
		} else {
			this.age = age;
		}
	}

}

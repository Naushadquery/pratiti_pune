package com.nau;

public class EmployeeApp {

	public static void main(String... args) {
		System.out.println("++++++++++++++++++++++++");
		for (String e : args) {
			System.out.println(e);
		}
		
		String n1 = args[0];
		String n2 = args[1];
		System.out.println(n1+n2);
		System.out.println("++++++++++++++++++++++++");
		Employee employee1 = new Employee();
		employee1.setId(1);
		employee1.setName("Naushad");
		employee1.setCity("Pune");
		Employee employee2 = new Employee();
		employee2.setId(2);
		employee2.setName("Akhtar");
		// employee2.setCity("Mumbai");

		Employee employees[] = { employee1, employee2 };
		displayEmployees(employee1, employee2);
		System.out.println("----------------------------");
		displayEmployees(employees);
		System.out.println("----------------------------");
		displayEmployees();
	}

	private static void displayEmployees(Employee... employees) {
		System.out.println(employees);
		for (Employee e : employees) {
			System.out.println(e);
//			System.out.print(e.getId() +"\t");
//			System.out.print(e.getName().toUpperCase() + "\t");
//			System.out.println(e.getCity().toUpperCase());
		}
	}

}

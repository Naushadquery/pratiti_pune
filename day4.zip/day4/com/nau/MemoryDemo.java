package com.nau;

public class MemoryDemo {
	public static void main(String[] args) {

		//System.out.println(System.currentTimeMillis());

		Runtime rt = Runtime.getRuntime();
System.out.println(rt.availableProcessors());
System.out.println();
		long maxmem = rt.maxMemory();
		System.out.println(maxmem);

		for (int i = 1; i < 10000000; i++) {
			Employee e = new Employee(i, "asdf", "asdf");
		}
		long freemem2 = rt.freeMemory();
		System.out.println(freemem2);

		System.out.println(System.currentTimeMillis());
	}
}

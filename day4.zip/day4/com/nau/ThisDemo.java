package com.nau;

public class ThisDemo {
	private static int xx = 45;
	private int age;
	private String name;

	public ThisDemo() {
		this(18, "Pakya");
	}

	public ThisDemo(int age) {
		this(age, "Pakya");
	}

	public ThisDemo(String name) {
		this(18, name);
	}

	public ThisDemo(int age, String name) {
		this(age,xx,name);
		this.age = age;
		this.name = name;
	}

	public ThisDemo(int i, int j, String name) {

	}

	public int getAge() {
		return this.age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}

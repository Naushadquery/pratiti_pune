package com.nau;

public class StringBufferDemo {
	
	public static void main(String[] args) {
		//Synchronized
		StringBuffer buffer = new StringBuffer("ASDF");
		System.out.println(buffer);
		buffer.append("Hello");
		System.out.println(buffer);
		
		StringBuilder builder = new StringBuilder("BBB");
		System.out.println(builder);
		builder.append("WORLD");
		System.out.println(builder);
	}

}

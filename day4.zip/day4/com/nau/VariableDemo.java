package com.nau;

public class VariableDemo {
	public static void main(String[] args) {
		new VD(10);
	}
}

class VD {
	int age;

	public VD(int age) {
		this.age = age;
		int j = 0;
		String s = "AA";
		System.out.println();
	}
	
	public int aa() {
		return age;
	}
}
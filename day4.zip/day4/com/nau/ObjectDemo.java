package com.nau;

class ChotiMoti extends Object{
	private String name;
	private String city;
	private String phone;

	public ChotiMoti(String name) {
		this.name = name;
		//System.out.println(name);
	}
	public void cName(String name) {
		this.name = name;
		this.city.toUpperCase();
	}
	@Override
	public String toString() {
		return "ChotiMoti [name=" + name + ", city=" + city + ", phone=" + phone + "]";
	}
	
}

public class ObjectDemo {
	private static void displayName(ChotiMoti chotiMoti) {
		System.out.println("Display" + chotiMoti);
	}
	public static void main(String[] args) {
		
		ChotiMoti chotiMoti = new ChotiMoti("Naushad");
		System.out.println(chotiMoti);
		chotiMoti.cName("Akhtar");
		displayName(chotiMoti);
//		String s="Aa";
//		String s1 = "BB";
//		System.out.println(s.hashCode() + "  "  + s1.hashCode());
//		
//		ChotiMoti moti = new ChotiMoti("Akhtar");
//		int hcode = moti.hashCode();
//		Class c = moti.getClass();
//		String cName = c.getName();
//		System.out.println(cName+"@"+Integer.toHexString(hcode));
//	//	String s = new String("Akhtar");
//		System.out.println(moti);
	}

	
}

package com.nau;

class MyString {
	
	private final String value;

	public MyString(String value) {
		this.value = value;
	}

	public String toupper() {
		String ss = value.toUpperCase();
		return ss;
	}
	

}

public class ImmuDemo {
	public static void main(String[] args) {

		String s1 = new String("Hello");
		MyString s = new MyString("Hello");
		Integer i = new Integer("a");
		int xx = i.intValue();
		System.out.println(xx*8);
		
	}
}

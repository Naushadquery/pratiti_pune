package com.nau;

public class ThisDemoApp {
	public static void main(String[] args) {
		ThisDemo demo = new ThisDemo("Naushad");
		//demo.setAge(44);
		System.out.println(demo.getAge());
		System.out.println(demo.getName());
	}
}

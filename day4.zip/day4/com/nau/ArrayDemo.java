package com.nau;

public class ArrayDemo {
	public static void main(String[] args) {

		int[] num = new int[5];
		num[0] = 100;
		num[1] = 1000;
		num[2] = 2000;
		num[3] = 3000;
		num[4] = 4000;

		for (int i = 0; i < num.length; i++) {
			System.out.println(num[i]);
		}
		System.out.println("--------------------");
		for (int x : num) {
			System.out.println(x);
		}
		num[4] = 2222;
		System.out.println("--------------------");
		for (int x : num) {
			System.out.println(x);
		}

	}

}

package com.nau;

public class Test {
	
	private int xx;
	
	public static void abc(int i) {
		System.out.println(i*i);
	}

	public void xyz(int i) {
		this.xx = i*i;
		Math.min(3, 6);
		System.out.println(this.xx);
	}
	public static void main(String[] args) {
		
		Test.abc(4);
	}
}

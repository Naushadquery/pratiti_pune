package com.nau;

class A{
	int x = 55;
}

public class WrapperDemo {
	public static void main(String[] args) {
		int i = 10;
		// Integer ii = new Integer(i); // boxing
		
			
		Integer x[] = {1,2,3};
		for (int j = 0; j < x.length; j++) {
		//	System.out.println(x[j]);
		}
		//tp(x,9);
		for (int j = 0; j < x.length; j++) {
		//	System.out.println(x[j]);
		}
		int age = 40;
	//	System.out.println(age);
		//tp(x, age);
		//System.out.println(age);
		A a = new A();
		System.out.println(a.x);
		pp(a);
		System.out.println(a.x);
	}

	private static void pp(A a) {
		a.x = 599;
		a = null;
	}

	public static void tp(Integer[] i,int age) {
		i[0]=30;
		age = 60;
		i = null;
		
	}
}

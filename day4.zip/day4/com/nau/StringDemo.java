package com.nau;

public class StringDemo {
	public static void main(String[] args) {
		
		String s1 = "Hello";
		String s2 = "Hello";
		String s3 = new String("Hello");
		String s33 = new String("Hello");
		String s34 = s33.intern();
		String s38 = "HelloHello";
		String s35 = s1+s2;
		System.out.println(s2==s34);
		s3 = null;
		s33 = null;
		String s8 = s1.toUpperCase();
		String s9 = s2.toUpperCase();
		//System.out.println(s);
//		String s4 = "H";
//		String s5 = "H";
//		String s6 = "H"+"H";
//		String s7 = "HH";
//		System.out.println(s6==s7);
//		
		
		//System.out.println(s1==s3);
		
	}

}

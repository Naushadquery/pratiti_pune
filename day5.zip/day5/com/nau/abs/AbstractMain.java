package com.nau.abs;

import java.awt.Dimension;
import java.awt.Toolkit;

public class AbstractMain {
	
	public static void main(String[] args) {
	//	House shouse = new SanketHouse();
		Toolkit t= Toolkit.getDefaultToolkit();
		Dimension d = t.getScreenSize();
		System.out.println(d);
		House vhouse = new Akash();
		DisplayHouse.displayHouse(vhouse);
	}
}
class DisplayHouse{
	public static void displayHouse(House house ) {
		house.bedroom();
		house.kitchen();
	}
}
abstract class SanketHouse extends House{
	@Override
	public void bedroom() {
		System.out.println("Bedroom with bed");
	}
}
abstract class VishakhaHouse extends House{
	public VishakhaHouse() {
		System.out.println("Vishakha House");
	}
}
 class Akash extends VishakhaHouse{

	@Override
	public void bathroom() {
		System.out.println("Radio BAthroom");
	}
	
}
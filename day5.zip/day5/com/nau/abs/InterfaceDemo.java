package com.nau.abs;

class XA implements IA {
	@Override
	public void ia() {
		System.out.println("IA Wala agaya");
	}
}

public class InterfaceDemo {
	 static class XB implements IB{

		@Override
		public void ib() {
			System.out.println("IB Wala agaya");
		}
		
	}
	public static void main(String[] args) {
		class XBI implements IB{

			@Override
			public void ib() {
				System.out.println("IB Wala agaya, local aaya");
			}
		}
		IB ib = new IB() {
			@Override
			public void ib() {
				System.out.println("IB Wala agaya, anonymous aaya");
			}};
		
		ZA za = new ZA();
		XA xa = new XA();
		za.ia_Service(xa);
		XBI xb = new XBI();
		za.ib_service(new IB() {
			@Override
			public void ib() {
				System.out.println("IB Wala agaya, ghar pe aaya");
			}});
	}
}

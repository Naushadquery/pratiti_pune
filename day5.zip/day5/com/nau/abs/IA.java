package com.nau.abs;

public interface IA {
	public void ia();
}

interface IB {
	void ib();
}


class ZA{
	public void ib_service(IB ib) {
		ib.ib();
	}
	public void ia_Service(IA ia) {
		ia.ia();
	}
}

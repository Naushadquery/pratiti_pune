package com.nau.abs;

class User {
	
//	public void useMotor(Motor motor) {
//		on_off(motor);
//	}
	public void on_off(PowerButton button) {
		button.on();
		button.off();
	}
	
}

public class WorkShop {
	
	public static void main(String[] args) {
		
		User motorUser = new User();
		Motor motor = new Motor();
		Pankha pankha = new Pankha();
		motorUser.on_off(pankha);
		

	} 

}

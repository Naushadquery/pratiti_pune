package com.nau.abs;

public abstract class House {
	
	public House() {
		System.out.println("House Object");
	}
	
	public void bedroom() {
		System.out.println("Normal bedroom");
	}
	public void kitchen() {
		System.out.println("Normal Kitchen");
	}
	public abstract void bathroom();
}

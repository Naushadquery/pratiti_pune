package com.nau.abs;

public interface PowerButton {
	void on();

	void off();
}
 interface Coil{
	void typeOf();
}
 
class Pankha implements PowerButton{

	@Override
	public void on() {
		System.out.println("Pankha On hogaya");
		
	}

	@Override
	public void off() {
		
		System.out.println("Pankha band hogaya");
	}
	
} 
class Motor implements PowerButton,Coil{
	@Override
	public void on() {
		System.out.println("Motor On hogaya");
	}
	@Override
	public void off() {
		System.out.println("Motor band hogaya");
	}

	@Override
	public void typeOf() {
		System.out.println("Copper winding");
	}
}
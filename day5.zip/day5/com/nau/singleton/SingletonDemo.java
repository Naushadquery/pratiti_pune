package com.nau.singleton;

public class SingletonDemo {
	private SingletonDemo() {
	}

	private int i; 
	public int getI() {
		return i;
	}
	
	public void setI(int i) {
		this.i = i;
	}
	
	private static SingletonDemo demo;
	static {
		demo = new SingletonDemo();
	}
	
	public static SingletonDemo getInstance() {
		return demo;
	}
}

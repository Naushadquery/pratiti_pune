package com.nau.nullpointer;


class Emp{
	private String name="Employee";

	public String getName() {
		return name;
	}
}

class Student{
	private String city="PUNE";

	public String getCity() {
		return city;
	}
}
public class NullPointerDemo {
	public static void main(String[] args) {
		Emp emp = new Emp();
		Student student = new Student();
		NP np = new NP();
		np.display("Hello");
	}
}
class Fruit{}
class NP{
	//private String s;
	public void display(Object o) {
		if(o instanceof Student) {
			Student s= (Student)o;
			System.out.println(s.getCity());
		}else if(o instanceof Emp){
			Emp e = (Emp)o;
			System.out.println(e.getName());
		}else {
			System.out.println("Object Not understood");
		}
	}
}
package com.nau.practice;

public class StudentMain {
	public static void main(String[] args) {
			
	}
}

package com.nau.b;

import com.nau.c.C;

public final class B extends C{
	public final int B_KA_VALUE;
	public B(int i) {
		super();
		this.B_KA_VALUE=i;
		System.out.println("int i constructor of B called : " + i);
	}
	
	@Override
	public void methodC() {
		System.out.println("methodC in class B");
		return ;
	}
	public void methodB() {
		System.out.println("methodB in class B");
	}
	@Override
	public  void methodCC() {
		System.out.println("methodCC in class C");
	}
	public void methodB(int i ) {
		System.out.println("methodB in class B with i : " + i);
		System.out.println(34.34);
	}
	public void methodBB() {
		System.out.println("methodBB in class B");
	}
}

package com.nau.model;

public class Employee {

	private int id;
	private String name;
	private String city;

	private Employee() {
	}

	public Employee(int id, String name, String city) {
		super();
		this.id = id;
		this.name = name;
		this.city = city;
	}

	public Employee(int id) {
		super();
		this.id = id;
	}

	public Employee(String name, String city) {
		super();
		this.name = name;
		this.city = city;
	}

}

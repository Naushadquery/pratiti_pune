package com.nau.clone;

public class EmployeeMain {
	
	public static void main(String[] args) throws CloneNotSupportedException {
//		Employee employee = new Employee(1,"Naushad");
//		Employee e = (Employee)employee.clone();
//		e.setName("akhtar");
//		System.out.println(employee);
//		System.out.println(e);
		A2 a2 = new A2();
		A1 a1= new A1(a2);
		a1.tp();
	}
}

class A2{
	public void a22() {
		System.out.println("A22");
	}
}
class A1 {
	A2 a2;
	public A1(A2 a2) {
		this.a2= a2;
	}
	public void tp() {
		a2.a22();
	}
}
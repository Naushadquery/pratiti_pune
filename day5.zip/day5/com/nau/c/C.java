package com.nau.c;
public class C {
	public C() {
		super();
		System.out.println("default constructor of C called");
	}
	public C(int i) {
		super();
		System.out.println("int i constructor of C called : " + i);
	}
	protected void methodC() {
		System.out.println("methodC in class C");
	}
	public void methodCC() {
		System.out.println("methodCC in class C");
	}
}

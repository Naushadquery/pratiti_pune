package com.nau.main;

import com.nau.a.A;
import com.nau.b.B;
import com.nau.c.C;

public class MainApp {
public static void main(String[] args) {
	
	B c = new B(9);
	c.methodC();
	
//	 Object b = new A();
//	 A a = (A)b;
//	 a.methodA();
//	 
//	 A a1 = new A(5);
//	 A a2 = new A(6);
//	 System.out.println(a1.equals(a2));
	//A a = new A(5);
	//A aa = new A();
	// System.out.println(a instanceof B);
	//System.out.println(a.getClass().getName());
}
}

package com.nau.a;
import java.util.Objects;

import com.nau.b.B;
public class A{
	public int a;
	public A() {
		this(0);
		System.out.println("default constructor of A called");
	}
	public A(int i) {
		
		this.a=i;
		System.out.println("int i constructor of A called : " + i);
	}
	public void methodA() {
		System.out.println("methodA in class A");
	}
	public void methodAA() {
		System.out.println("methodAA in class A");
	}
	@Override
	public int hashCode() {
		return Objects.hash(a);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		A other = (A) obj;
		return a == other.a;
	}
	
}

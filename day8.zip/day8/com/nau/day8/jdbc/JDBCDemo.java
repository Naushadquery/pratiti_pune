package com.nau.day8.jdbc;

import java.sql.*;

public class JDBCDemo {
	
	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		
		//DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
//		Class.forName("com.mysql.cj.jdbc.Driver");
//		System.out.println("Driver Loaded");
		String url="jdbc:mysql://localhost:3306/naushad"; // jdbc:oracle:thin:@loca
		String user="naushad";
		String password="naushad";
		Connection connection = DriverManager.getConnection(url,user,password);
		System.out.println("Connection established");
		String query = "select * from student";
		Statement st= connection.createStatement(); 
		DatabaseMetaData dbmd = connection.getMetaData();
		ResultSet rs =  st.executeQuery(query);
		ResultSetMetaData rsmd= rs.getMetaData();
		rsmd.getColumnCount();
		while(rs.next()) {
			System.out.println(rs.getInt(1) + " : " + rs.getString(2) + " : " + rs.getString(3));
		}
	
	}

}

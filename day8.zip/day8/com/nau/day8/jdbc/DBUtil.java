package com.nau.day8.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {
	private static Connection connection;

	private DBUtil() {}
	static{
		String url = "jdbc:mysql://localhost:3306/naushad"; // jdbc:oracle:thin:@loca
		String user = "naushad";
		String password = "naushad";
		try {
			connection = DriverManager.getConnection(url, user, password);
			System.out.println("Connection established");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	public static Connection getConnection() {
		return connection;
	}

}

package com.nau.day8.jdbc;

import java.util.List;

import com.nau.practice.Student;

public class StudentService {
	
	private StudentDAO dao = new StudentDAO();
	
	public void addStudent(Student student) {
		student.setName(student.getName().toUpperCase());
		int r = dao.addStudent(student);
		if(r==0) {
			System.out.println("Not successfull");
		}else {
			System.out.println(" successfull");
		}
	}

	public List<Student> getAllStudents() {
		return dao.getAllStudents();
		
	}

}

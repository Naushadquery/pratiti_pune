package com.nau.day8.jdbc;

import java.util.List;

import com.nau.practice.Student;

public class StudentView {

	public static void main(String[] args) {

		StudentService service = new StudentService();

		Student student = new Student(103, "Vishakha", 50);

		//service.addStudent(student);

		List<Student> students = service.getAllStudents();
		students.forEach(e -> System.out.println(e.getId() + ":" + e.getName() + ":" + e.getAge()));

	}

}

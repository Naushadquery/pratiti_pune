package com.nau.day8.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.nau.practice.Student;

public class StudentDAO {
	
	private Connection connection = DBUtil.getConnection();
	
	public int addStudent(Student student) {
		int id = student.getId();
		String name = student.getName();
		int age = student.getAge();
		String sql = "insert into student values(?,?,?)";
		try {
			PreparedStatement ps= connection.prepareStatement(sql);
			ps.setInt(1, id);
			ps.setString(2, name);
			ps.setInt(3, age);
			return ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}

	public List<Student> getAllStudents() {
		String sql = "select * from student";
		List<Student> students = new ArrayList<Student>();
		try {
			PreparedStatement ps = connection.prepareStatement(sql);
			ResultSet rs =  ps.executeQuery();
			while(rs.next()) {
				students.add(new Student(rs.getInt(1),rs.getString(2),rs.getInt(3)));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return students;
	}

}

package com.nau.day8;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.function.BiFunction;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

class NumberPrinter {
	public static Void printNumber(Integer num1, Integer num2) {
		System.out.println(num1 + num2);
		return null;
	}
//	
}

public class StreamDemo {

	public static void main(String[] args) {
		List<Integer> numbers = Arrays.asList(3, 5, 1, 4, 4, 7, 7, 6, 2, 7, 8);
		Stream<Integer> stream1 = numbers.stream();
		long l = stream1.distinct().count();
		System.out.println(l);
		//Stream<Integer> stream2 = numbers.stream();
//		Predicate<Integer> p =new Predicate<>() {
//			public boolean test(Integer t) {
//				return t==4;
//			};
//		};
//		boolean b = stream2.allMatch(t -> t == 4);
//		System.out.println(b);
//		Stream<Integer> stream3 = numbers.stream();
//		boolean b1 = stream3.anyMatch(t -> t == 4);
//		System.out.println(b1);
//		Stream<Integer> stream4 = numbers.stream();
//		stream4.limit(3).forEach(System.out::println);
//		Stream<Integer> stream5 = numbers.stream();
//		stream5.filter(t->t==4).forEach(System.out::println);
//		Stream<Integer> stream6 = numbers.stream();
//		List<Integer> numberLessThanSix = stream6.filter(t->t<6).collect(Collectors.toList());
		
		Stream<Integer> s7 = numbers.stream();
		List<Integer> li =  s7.filter(x->x>6).map(x->x*3).collect(Collectors.toList());
		li.forEach(System.out::println);
		
	}

}

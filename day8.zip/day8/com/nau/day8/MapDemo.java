package com.nau.day8;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.BiConsumer;

public class MapDemo {
	
	public static void main(String[] args) {
		
		Map<Integer, Employee> map = new HashMap<Integer, Employee>();
		System.out.println(map.put(1, new Employee(1, "Nasya1")));
		System.out.println(map.put(2, new Employee(2, "Nasya2")));
		System.out.println(map.put(3, new Employee(3, "Nasya3")));
		System.out.println(map.putIfAbsent(4, new Employee(4, "Nasya4")));
		System.out.println(map.put(5, new Employee(5, "Nasya5")));
		
		BiConsumer<Integer, Employee> bc = new BiConsumer<Integer, Employee>() {
			
			@Override
			public void accept(Integer t, Employee u) {
				System.out.println(t + " : " + u);
			}
		};
		//map.forEach(bc);
		Collection<Employee> emp= map.values();
		Optional<Employee> e = emp.stream().filter(p->p.getId()==4).findFirst();
		boolean  b = e.isPresent();
		System.out.println(b);
		if(b) {
			Employee ee= e.get();
			System.out.println(ee);
		}
		//e.ifPresent(ee->System.out.println(ee.getName()));
//		Set<Integer> st=  map.keySet();
//		for(int i : st) {
//			System.out.println(map.get(i));
//		}
		//System.out.println(map.get(3));
	}

}

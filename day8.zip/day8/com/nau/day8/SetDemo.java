package com.nau.day8;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class SetDemo {

	public static void main(String[] args) {

		employeeDemo();
//
//		Set<String> set = new TreeSet<>();
//		System.out.println(set.add("banana"));
//		System.out.println(set.add("apple"));
//		System.out.println(set.add("chickoo"));
//		System.out.println(set.add("banana"));
//		System.out.println(set.add("applee"));
//		System.out.println(set.add("tabple"));
//		set.forEach(f->System.out.println(f));
	}

	private static void employeeDemo() {
		Employee f1 = new Employee(7, "Naushad");
		Employee f2 = new Employee(5, "Zaha");
		Employee f3 = new Employee(3, "Taha");
		Employee f4 = new Employee(2, "Akhtar");
		System.out.println(f1.equals(f2));
		Set<Employee> employees = new HashSet<>();
		employees.add(f1);
		employees.add(f2);
		employees.add(f3);
		employees.add(f4);
		
		List<Employee> e= employees.parallelStream().filter(emp->emp.getId()>3).toList();
		e.forEach(em-> System.out.println(em.getId() + " : " + em.getName()));
		List<Employee> list = new ArrayList<Employee>(employees);
		// employees.add(f5);
		//list.forEach(e -> System.out.println(e));
		Comparator<Employee> cname = new Comparator<Employee>() {
			@Override
			public int compare(Employee o1, Employee o2) {
				return o1.getName().compareTo(o2.getName());
			}
		};
		Comparator<Employee> cid = new Comparator<Employee>() {
			@Override
			public int compare(Employee o1, Employee o2) {
				return o1.getId() - o2.getId();
			}
		};
		Collections.sort(list, (e1, e2) -> e1.getId() - e2.getId());
		System.out.println("==================");
	//	list.forEach(e -> System.out.println(e)); 
	}
}

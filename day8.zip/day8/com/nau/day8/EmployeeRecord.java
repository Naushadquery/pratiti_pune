package com.nau.day8;

public record EmployeeRecord(int id,String name) {
	public EmployeeRecord (int id){
		this(id,null);
	}
}

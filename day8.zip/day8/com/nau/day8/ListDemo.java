package com.nau.day8;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Vector;

public class ListDemo {

	public static void main(String[] args) {

		int i[] = new int[10]; //
		i[0] = 10;
		List<String> al = new ArrayList<>(20);
		System.out.println();
		al.add("mouse");
		al.add("cat");

		List<String> v = new Vector<String>(10, 2); // synchronized
		
		List<String> al2 = new LinkedList<String>(al);
		al2.add("dog");
		
		Object o[] = al2.toArray();
		for(Object oo : o) {
			//String s = (String)oo;
			System.out.println(oo);
		}

//		String s[] = (String[])al2.toArray();
//		for(String ss : s) {
//			System.out.println(ss);
//		}
		
//		Predicate<String> p = new Predicate<String>() {
//			@Override
//			public boolean test(String t) {
//				return t.equals("cat");
//			}
//		};
//		al2.removeIf(t -> t.equals("cat"));
//		System.out.println(al2.indexOf("mouse"));
//		// al2.set(2,"kuuta");
//		// listIterator(al2);
//		// forEachMethod(al2);
//		// forLoop(al2);
//		forEachStream(al2);

	}

	private static void forEachStream(List<String> al2) {
//		Consumer<String> consumer = new Consumer<String>() {
//			
//			@Override
//			public void accept(String t) {
//				t = t.toUpperCase();
//				System.out.println(t.toUpperCase());
//			}
//		};

		// Consumer<String> con = x->System.out.println(x.toUpperCase());

		al2.forEach(System.out::println);

	}

	private static void forLoop(List<String> al2) {
		for (int j = 0; j < al2.size(); j++) {
			System.out.println(al2.get(j).toUpperCase());
		}

	}

	private static void forEachMethod(List<String> al) {
		for (String s : al) {
			System.out.println(s.toUpperCase());
		}
	}

	private static void listIterator(List<String> al) {
		ListIterator<String> it = al.listIterator();
		while (it.hasNext()) {
			String o = it.next();
			System.out.println(o.toUpperCase());
		}
	}
}

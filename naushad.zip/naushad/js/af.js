total = (x, y) => {
  return x + y;
};
console.log(total(4, "A"));

var d = Date();
console.log(d);
const today = new Date();
console.log(today);
var month = today.toLocaleDateString();
console.log(month);

class EmployeeC {
  // name: string;
  // city: string;
  constructor(name, city) {
    this.name = name;
    this.city = city;
  }
  getName() {
    return this.name;
  }
  getCity() {
    return this.city;
  }
}
let empC = new EmployeeC("PApapa", "puneee");
console.log(empC.getName() + " : " + empC.getCity());

function EmployeeF(name, city) {
  this.name = name;
  this.city = city;
  this.getName = function () {
    return this.name;
  };
  this.getCity = function () {
    return this.city;
  };
}
let empF1 = new EmployeeF("Altaf", "Latur");
let empF2 = new EmployeeF("Angad", "Pune");
e = JSON.stringify(empF1);
console.log(e);

let empF3 = [
  {
    fname: "sakshi",
    place: "kolhapur",
    phone: { home: 989898, office: 999999 },
    retire: true,
    getFname: function () {
      return this.fname;
    },
  },
  {
    fname: "mehta",
    place: "solapur",
    getFname: function () {
      return this.fname;
    },
  },
];
console.table(empF3);

// JSON
// let empF4String = JSON.stringify(empF3);
// console.log(empF4String);
// let empS = '{ "lname": "sakshi", "ghar": "kolhapur" }';
// console.log(empS.lname);

// let empF5JSON = JSON.parse(empS);

// //emloyees.forEach((emp) => console.log(emp.name));
// console.log(empF5JSON.lname);

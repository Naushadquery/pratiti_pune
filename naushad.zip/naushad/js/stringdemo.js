var s2 = "hello";
var s1 = new String("hello");

console.log(s1 == s2);
var s3 = "Helllll";

console.log(`this is ${s3} sadj assa sd sd`);

console.log("Start");
setTimeout(
  function (x) {
    len = arguments;
    console.table(len);
  },
  2000,
  555,
  666,
  878
);
console.log(arguments);

function pp() {
  console.log("pp start");
  for (let index = 0; index < 5; index++) {
    console.log(index);
  }
  console.log("pp end");
}

function mm(...a) {
  for (let index = 0; index < a.length; index++) {
    console.log(a[index]);
  }
}
//mm(1, 2, 3, 3, 33);
console.log("End");

console.log("HEllo World");
var x = 10;
var x = 40;

let y;
y = 22;

const z = 567;

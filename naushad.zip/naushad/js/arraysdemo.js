const a1 = [1, 2, 5, , 9];
const b1 = [1, 2, 5, , 9];
c3 = a1.concat(b1);

console.log(a1);

a1[10] = 45;
const a11 = "sadf";

console.log(a1.length);
console.log(a1[3]);
let a2 = new Array(20);
a3 = a1.concat(a2);
for (i in c3) {
  console.log("in wala " + c3[i]);
}
a3.forEach((d) => console.log("for each wala" + d));
for (let index = 0; index < a3.length; index++) {
  const element = a3[index];
  if (element != undefined) {
    console.log(element);
  }
}

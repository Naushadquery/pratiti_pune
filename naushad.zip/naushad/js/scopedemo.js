var x = 10;
{
  let y = 40;

  console.log(x);
  {
    let z = 5;
    const yy = 440;
    console.log(y);
  }
  //console.log(z);
}
//console.log(y);
console.log(yy);

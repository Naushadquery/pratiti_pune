console.log("Hotel");

function order(item, xyz) {
  console.log("ORder placed " + item);
  console.log(item + "is getting ready");
  setTimeout(() => {
    return xyz(item + " is ready to server");
  }, 5000);
}

order("idli", (itemStatus) => {
  console.log(itemStatus);
});
console.log("Kapda dho leta hoon");

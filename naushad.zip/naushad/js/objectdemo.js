let x = new Object();

class B {
  getB() {}
}

class A extends B {
  getA() {}
}

String.prototype.meraadd = function () {
  return this.charAt(3);
};

xx = "NAushad";
console.log(xx.meraadd());

function Student(fname, lname) {
  this.fname = fname;
  this.lname = lname;
}
Student.prototype.validateEmail = function () {};
Student.prototype.fullName = function () {
  console.log(this.fname + this.lname);
};

console.log(Student.prototype);

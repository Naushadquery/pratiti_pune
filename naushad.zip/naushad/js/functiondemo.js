function f1(x, y) {
  var xx = 20;
  var l1 = 11;
  //console.log("f1 called : " + x + y);
  for (let p = 1; p < 100; p++) {}
  {
    let l2 = 22;
    console.log(l1);
    //console.log(p);
  }
  {
    //console.log(l2);
  }
  console.log(l1);
  // return x + y;
}
res = f1(58, 2);
console.log(res);
//console.log(xx);

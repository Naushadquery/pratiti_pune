function sum(a, b, c) {
  len = arguments.length;
  switch (len) {
    case 1:
      return a;
    case 2:
      return a + b;
    case 3:
      return a + b + c;
  }
  return;
}
r = sum();
console.log(r);

// function sum() {
//   arg = arguments;
//   console.log(arg);
//
//   console.log("sum ");
// }
// res = sum(true, "pappu", 45, 989, 454.5665);
// console.log(res);

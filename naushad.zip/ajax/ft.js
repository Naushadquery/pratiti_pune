const data = { userid: "ansuahd" };
console.log("AAAAA" + data.userid);
let options = {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
  },
  body: '{"userid":"naushad"}',
};
console.log(options);
fetch("http://localhost:8080/ajax/validate.jsp", options)
  .then((r) => r.json())
  .then((d) => console.log(d));

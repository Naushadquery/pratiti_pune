package com.nau.vet;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

import com.nau.pet.Cat;

public class Vet {
	
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		
		FileInputStream fis = new FileInputStream("blanket.txt");
		ObjectInputStream ois = new ObjectInputStream(fis);
		Object object = ois.readObject();
		System.out.println(object);
		Cat cat = (Cat)object; 
		System.out.println(cat.getSound());
		cat.setSound("MEWOWOWOWOWO");
		System.out.println(cat.getSound());
	}
}

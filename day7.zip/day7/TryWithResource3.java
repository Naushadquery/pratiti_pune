import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;

public class TryWithResource3 {
	public static void main(String[] args) {

		try (FileOutputStream fos = new FileOutputStream("abc.txt",true);
				OutputStreamWriter  osr = new OutputStreamWriter(fos);
				BufferedWriter bw = new BufferedWriter(osr)) {
//			byte b[] = fis.readAllBytes();
//			String s = new String(b);
//			System.out.println(s);
			//bw.append("HElo");
		
			FileWriter f= new FileWriter("abc1.txt",true);
			f.write("asdfasd\n\r");
			f.flush();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}

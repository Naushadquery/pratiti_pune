import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;

public class TryWithResource2 {
	public static void main(String[] args) {

		try (MeraResource meraResource = new MeraResource()) {
			System.out.println("End");
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		try (FileInputStream fis = new FileInputStream("abc.txt");
				InputStreamReader isr = new InputStreamReader(fis);
				BufferedReader br = new BufferedReader(isr)) {
//			byte b[] = fis.readAllBytes();
//			String s = new String(b);
//			System.out.println(s);
			String s = "";
			while ((s = br.readLine()) != null) {
				System.out.println(s);
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}

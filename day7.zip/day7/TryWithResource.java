import java.io.FileInputStream;
import java.io.IOException;

public class TryWithResource {
	public static void main(String[] args) {
		FileInputStream fis = null;
		
		try {
			fis = new FileInputStream("abc.txt");
			int data = 0;
			byte b[] = fis.readAllBytes();
			String s = new String(b);
			System.out.println(s);
//			while ((data = fis.read()) != -1) {
//				System.out.print((char)data);
//			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (fis != null) {
					fis.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}
}

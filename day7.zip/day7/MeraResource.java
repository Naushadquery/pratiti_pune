
public class MeraResource implements AutoCloseable {

	public MeraResource() {
		System.out.println("MEra Resource created");
	}

	@Override
	public void close() throws Exception {
		System.out.println("Mera Resource Close Hogaya");
	}

}

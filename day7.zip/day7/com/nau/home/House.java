package com.nau.home;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

import com.nau.pet.Cat;

public class House {
	
	public static void main(String[] args) {
		
		Cat cat = new Cat("Luna", "Pershian", "Meow Meow") ;
		System.out.println(cat);
		// time pass hoga 
		cat.setSound("meee  meeee");
		System.out.println(cat);
		
		try {
			FileOutputStream fos = new FileOutputStream("blanket.txt");
			ObjectOutputStream ois = new ObjectOutputStream(fos);
			ois.writeObject(cat);
			System.out.println("Cat saved in blanket");
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}

}

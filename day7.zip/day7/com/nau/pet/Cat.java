package com.nau.pet;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

public class Cat implements Externalizable{

	private static final long serialVersionUID = 1L;
	private String name;
	private String breed;
	private String sound;

	public Cat() {
	}

	public Cat(String name, String breed, String sound) {
		super();
		this.name = name;
		this.breed = breed;
		this.sound = sound;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBreed() {
		return breed;
	}

	public void setBreed(String breed) {
		this.breed = breed;
	}

	public String getSound() {
		return sound;
	}

	public void setSound(String sound) {
		this.sound = sound;
	}

	@Override
	public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
		//name = (String)in.readObject();
		breed = (String)in.readObject();
		sound = (String)in.readObject();
	}
	
	@Override
	public void writeExternal(ObjectOutput out) throws IOException {
		out.writeObject(breed);
		out.writeObject(sound);
		
	}
	@Override
	public String toString() {
		return "Cat [name=" + name + ", breed=" + breed + ", sound=" + sound + "]";
	}
}

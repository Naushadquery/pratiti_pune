package com.nau.day7;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class ReadData {
	public static void main(String[] args) throws FileNotFoundException {

		File file = new File("numbers.txt");
		Scanner fileScanner = new Scanner(file);
		int sum = 0;
		while(fileScanner.hasNextInt()) {
			sum = sum+fileScanner.nextInt();
		}
		System.out.println(sum);
//		Scanner scanner = new Scanner("numbers.txt");
//		System.out.println("Enter Name :");
//		String s1 = scanner.nextLine();
//		System.out.println(s1);
//		Integer i1 = scanner.nextInt();
//		System.out.println(i1);
//		scanner.nextLine();
//		String s2 = scanner.nextLine();
//		System.out.println(s2);
//		scanner.close();
//		
		
	}
}
